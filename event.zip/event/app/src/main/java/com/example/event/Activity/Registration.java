package com.example.event.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.event.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class Registration extends AppCompatActivity {
EditText phone,pass;
    private FirebaseAuth mAuth;
    Button registerbutton;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        mAuth = FirebaseAuth.getInstance();
        phone = findViewById(R.id.phonenumber);
        pass=findViewById(R.id.password_reg);
registerbutton=findViewById(R.id.registerbutton);

registerbutton.setOnClickListener(new View.OnClickListener() {
    @Override
    public void onClick(View v) {

        rigster();
    }
});



    }


    public  void rigster(){
        mAuth.createUserWithEmailAndPassword(phone.getText().toString(),pass.getText().toString()).
                addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful())
                        {
                            Toast.makeText(Registration.this, "succ", Toast.LENGTH_SHORT).show();

                        } else {



                        }


                    }
                });
    }
}
