package com.example.event.Pristnter.PrisnterHome;

import com.example.event.Activity.IHome;

public interface IHomePrisnter {
 public    void LoaddataHome(IHome iHome);
}
