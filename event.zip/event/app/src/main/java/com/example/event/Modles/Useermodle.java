package com.example.event.Modles;

import java.util.ArrayList;

public class Useermodle
{

String name ;
String image;

ArrayList<String>eventadded;

    public Useermodle(String name, String image, ArrayList<String> eventadded) {
        this.name = name;
        this.image = image;
        this.eventadded = eventadded;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public ArrayList<String> getEventadded() {
        return eventadded;
    }

    public void setEventadded(ArrayList<String> eventadded) {
        this.eventadded = eventadded;
    }
}
