package com.example.event.Modles;

public class Events {
    public String name,type,image,discription,id;

    public Events(String id,String name, String type, String image, String discription) {
        this.name = name;
        this.type = type;
        this.image = image;
        this.discription = discription;
        this.id=id;
    }
    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getImage() {
        return image;
    }

    public void setImage(String image) {
        this.image = image;
    }

    public String getDiscription() {
        return discription;
    }

    public void setDiscription(String discription) {
        this.discription = discription;
    }
}
