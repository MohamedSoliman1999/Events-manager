package com.example.event.Pristnter.PrisnterHome;

import com.example.event.Activity.IHome;
import com.example.event.Modles.ModleHome;
import com.example.event.Repository.RepositryHome.HomeReositry;
import com.example.event.Repository.RepositryHome.IHomeReositry;

import java.util.ArrayList;

public class HomePrisnter implements IHomePrisnter {
 IHomeReositry iHomeReositry=new HomeReositry();
    @Override
    public void LoaddataHome(IHome home)
    {
        ArrayList<ModleHome> modleHomes_list=new ArrayList<>();
        modleHomes_list= iHomeReositry.getdatafromfirbase();
        home.setdata(modleHomes_list);
    }
}
