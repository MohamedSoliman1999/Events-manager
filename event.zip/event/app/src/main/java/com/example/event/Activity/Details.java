package com.example.event.Activity;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

import com.example.event.R;

public class Details extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_details);
    }
}
