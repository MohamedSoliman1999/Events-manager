package com.example.event.Activity;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

import com.example.event.R;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.PhoneAuthProvider;

import java.util.concurrent.TimeUnit;

public class Login extends AppCompatActivity {
Button Logen;
TextView textView,email_login,pass_login;
    private FirebaseAuth mAuth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        Logen=findViewById(R.id.button_login_id);
        textView=findViewById(R.id.singup_text);
        mAuth = FirebaseAuth.getInstance();
email_login=findViewById(R.id.email_login_id);
pass_login=findViewById(R.id.password_login_id);

        textView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(Login.this,Registration.class));
            }
        });
        Logen.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
             login();
            }
        });
    }

    public void login(){

        mAuth.signInWithEmailAndPassword(email_login.getText().toString(),pass_login.getText().toString()).addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
           if(task.isSuccessful()){
               startActivity(new Intent(Login.this,Home.class));
           }
            }
        });


    }
}
