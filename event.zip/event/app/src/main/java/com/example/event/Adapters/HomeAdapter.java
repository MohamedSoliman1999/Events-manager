package com.example.event.Adapters;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.example.event.Activity.Details;
import com.example.event.Modles.ModleHome;
import com.example.event.R;

import java.util.ArrayList;

public class HomeAdapter extends RecyclerView.Adapter<HomeAdapter.Holder> {


    private ArrayList<ModleHome> modleHomes = new ArrayList<>();
    private Context mContext;

    public HomeAdapter(Context context, ArrayList<ModleHome> modleHomes) {
        this.modleHomes = modleHomes;
        this.mContext = context;
    }

    @NonNull
    @Override
    public Holder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.itemhome, parent, false);
        Holder holder = new Holder(view);
        return holder;
    }

    @Override
    public void onBindViewHolder(@NonNull Holder holder, final int position) {

        holder.imageView.setImageResource(modleHomes.get(position).getImageUri());
        holder.textView_type.setText(modleHomes.get(position).getType());
        holder.textView_dis.setText(modleHomes.get(position).getDiscrption());
        holder.textView_date.setText(modleHomes.get(position).getDate());
        holder.linearLayout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(mContext, Details.class);
                //id for this event
             //   intent.putExtra("data_of_item",/*id for event coming soon*/);

                mContext.startActivity(intent);
            }
        });

    }

    @Override
    public int getItemCount() {
        return modleHomes.size();
    }

    public class Holder extends RecyclerView.ViewHolder {
        LinearLayout linearLayout;
        ImageView imageView;
        TextView textView_type;
        TextView textView_date;
        TextView textView_dis;

        public Holder(@NonNull View itemView) {
            super(itemView);

            linearLayout = itemView.findViewById(R.id.parnt_home_id);
            textView_date = itemView.findViewById(R.id.date_of_event_id_home);
            textView_dis = itemView.findViewById(R.id.dis_event_id_home);
            textView_type = itemView.findViewById(R.id.type_of_event_id_home);
            imageView = itemView.findViewById(R.id.image_item_home_id);



        }
    }

}
