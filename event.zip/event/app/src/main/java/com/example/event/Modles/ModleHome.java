package com.example.event.Modles;

import java.io.Serializable;

public class ModleHome implements Serializable {

    String discrption;
    String type;
    int imageUri;
    String date;

    public ModleHome(String discrption, String type, int imageUri, String date) {
        this.discrption = discrption;
        this.type = type;
        this.imageUri = imageUri;
        this.date = date;
    }

    public String getDiscrption() {
        return discrption;
    }

    public void setDiscrption(String discrption) {
        this.discrption = discrption;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public int getImageUri() {
        return imageUri;
    }

    public void setImageUri(int imageUri) {
        this.imageUri = imageUri;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }
}
