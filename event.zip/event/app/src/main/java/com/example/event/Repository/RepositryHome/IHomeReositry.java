package com.example.event.Repository.RepositryHome;

import com.example.event.Modles.ModleHome;

import java.util.ArrayList;

public interface IHomeReositry {
    ArrayList<ModleHome> getdatafromfirbase();
}
