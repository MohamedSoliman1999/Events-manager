package com.example.event.Activity;

import com.example.event.Modles.ModleHome;

import java.util.ArrayList;

public interface IHome {

    public void setdata(ArrayList<ModleHome> modleHomeArrayList);
}
