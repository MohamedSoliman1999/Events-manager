package com.example.event.Activity;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.example.event.Modles.Events;
import com.example.event.R;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

public class AddEvent extends AppCompatActivity {
    private TextView thedate;
    Button Adddate;

    ImageView photoImageView;
    private static final int RC_PHOTO_PICKER = 2;
    private ChildEventListener EChildEventListener;
    private FirebaseDatabase EFirebaseDatabase;
    private DatabaseReference EMessageDatabaseRefrence;
    private FirebaseAuth.AuthStateListener mAuthStateListener;
    private FirebaseStorage EFirebaseStorage;
    private StorageReference EImgPhotoStorageReference;
    private StorageReference photoRef;
    public String imgUri;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_add_event);
        initialization();
        Intent incoming = getIntent();
        String date = incoming.getStringExtra("date");
        thedate.setText(date);
        Adddate.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(AddEvent.this,Calennder.class);
                startActivity(intent);
            }
        });
        photoImageView=findViewById(R.id.imgEvemt);
        //***************************************************
        //for Storage firebase
        EFirebaseStorage = FirebaseStorage.getInstance();
        //for realtime
        EFirebaseDatabase = FirebaseDatabase.getInstance();
        EMessageDatabaseRefrence = EFirebaseDatabase.getReference().child("Events");
        EImgPhotoStorageReference = EFirebaseStorage.getReference().child("Events_Img");
        detattachedDatabaseReadListener();
        attachedDatabaseReadListener();
    }
    public void openGallry() {
        Intent intent = new Intent(Intent.ACTION_GET_CONTENT);
        intent.setType("image/jpeg");
        intent.putExtra(Intent.EXTRA_LOCAL_ONLY, true);
        startActivityForResult(Intent.createChooser(intent, "Complete action using"), RC_PHOTO_PICKER);
    }
    private void initialization() {
        Adddate=findViewById(R.id.add_date_event);
        thedate=findViewById(R.id.date_for_event);
    }
    public void OpenGallaryClick(View view) {
       openGallry();
    }

    private void attachedDatabaseReadListener() {
        if (EChildEventListener == null) {
            EChildEventListener = new ChildEventListener() {
                @Override
                public void onChildAdded(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                    //for(DataSnapshot snapshot : dataSnapshot.getChildren())
                    //{
                       // Events eventData = dataSnapshot.getValue(Events.class);
                    //}
                   //here you need to add event in list
                }

                @Override
                public void onChildChanged(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                }

                @Override
                public void onChildRemoved(@NonNull DataSnapshot dataSnapshot) {
                }

                @Override
                public void onChildMoved(@NonNull DataSnapshot dataSnapshot, @Nullable String s) {
                }

                @Override
                public void onCancelled(@NonNull DatabaseError databaseError) {}
            };
            EMessageDatabaseRefrence.addChildEventListener(EChildEventListener);
        }
    }

    private void detattachedDatabaseReadListener() {
        if (EChildEventListener != null) {
            EMessageDatabaseRefrence.removeEventListener(EChildEventListener);
            EChildEventListener = null;
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_PHOTO_PICKER && resultCode == RESULT_OK) {
            Uri selectedImageUri = data.getData();
            Toast.makeText(getApplicationContext(), "add successfully", Toast.LENGTH_SHORT).show();
            // Get a reference to store file at chat_photos/<FILENAME>
            final StorageReference photoRef = EImgPhotoStorageReference.child(selectedImageUri.getLastPathSegment());
            // Upload file to Firebase Storage
            photoRef.putFile(selectedImageUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    photoRef.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            Uri downloadUrl = uri;
                            imgUri=downloadUrl.toString();
                            Glide.with(photoImageView.getContext())
                                    .load(imgUri)
                                    .into(photoImageView);
                            Toast.makeText(getApplicationContext(),downloadUrl.toString(),Toast.LENGTH_SHORT).show();
                        }
                    });
                }


            });
        }
    }
    public void SubmitClick(View view) {
        Events event = new Events("1", "Mohamed","Action",imgUri,"any words" );
        EMessageDatabaseRefrence.push().setValue(event);

    }
}
