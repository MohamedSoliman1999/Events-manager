package com.example.event.Repository.RepositryHome;

import android.content.Context;

import com.example.event.Modles.ModleHome;
import com.example.event.R;

import java.util.ArrayList;

public class HomeReositry implements IHomeReositry {
Context context;
    @Override
    public ArrayList<ModleHome> getdatafromfirbase()

    {
        final ArrayList<ModleHome> modleHomes_list=new ArrayList<>();

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting", R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));

        modleHomes_list.add(new ModleHome("the sdv sdv sdvl ldv dvkj v skdjv kjdvn wldk ","Sporting",R.drawable.itemimage,"20-2-2020"));
      //Toast.makeText(context, ""+modleHomes_list.size(), Toast.LENGTH_SHORT).show();
        return modleHomes_list;
    }
}
